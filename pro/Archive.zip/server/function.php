<?php
/**
 * Created by PhpStorm.
 * User: shahzadmiraj
 * Date: 02/01/2019
 * Time: 5:07 PM
 */
require "connection.php";

function getcats()
{
    global  $con;
    $getCatquery="select * from categories";
    $result=mysqli_query($con,$getCatquery);
}
?>