<?php
/**
 * Created by PhpStorm.
 * User: shahzadmiraj
 * Date: 02/01/2019
 * Time: 5:06 PM
 */


 $con=mysqli_connect("localhost","root","","");
    if(!$con)
    {
        die("connection failed to database");
    }

?>